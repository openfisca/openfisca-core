import numpy

ENUM_ARRAY_DTYPE = numpy.int16
