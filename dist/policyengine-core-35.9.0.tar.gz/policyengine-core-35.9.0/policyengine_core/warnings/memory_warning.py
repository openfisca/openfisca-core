class MemoryConfigWarning(UserWarning):
    """
    Custom warning for MemoryConfig.
    """

    pass
